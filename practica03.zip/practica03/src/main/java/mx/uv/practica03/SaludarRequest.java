package mx.uv.practica03;

public class SaludarRequest {

}
